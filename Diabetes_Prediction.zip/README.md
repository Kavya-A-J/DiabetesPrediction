# DIABETES PREDICTION

**From a given data, our task is to predict that person have diabetes or not with the help of Machine Learning techniques.**

For this task we are going choose suitable **Machine Learning Classification Algorithm** with the help of **SKLEARN PIPELINE**. Select that algorithm for predicting diabetes disease and evaluate model with various techniques.

## This is very intresting Project check out!

# Thank You! 